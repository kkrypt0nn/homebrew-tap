package commands

import (
	"github.com/spf13/cobra"
)

var (
	output         string
	policy         string
	violationsOnly bool
	disabledRules  []string
)

func init() {
	rootCmd.AddCommand(evalCmd)

	evalCmd.PersistentFlags().StringVarP(
		&output,
		"output",
		"o",
		"stdout",
		"Output format: stdout or json",
	)
	evalCmd.PersistentFlags().StringVarP(
		&policy,
		"policy",
		"p",
		"restricted",
		"Policy to evaluate against: baseline or restricted",
	)
	evalCmd.PersistentFlags().BoolVarP(
		&violationsOnly,
		"violations",
		"V",
		false,
		"Show only rule violations",
	)
	evalCmd.PersistentFlags().StringSliceVar(
		&disabledRules,
		"disable-rule",
		nil,
		"Disable a specific rule by ID (e.g. pss:baseline:apparmor)",
	)
}

var evalCmd = &cobra.Command{
	Use:   "eval",
	Short: "Evaluate Kubernetes resources against Pod Security Standards.",
}
