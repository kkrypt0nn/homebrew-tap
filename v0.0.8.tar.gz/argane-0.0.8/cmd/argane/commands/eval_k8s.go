package commands

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/kkrypt0nn/argane/internal/engine"
	"github.com/kkrypt0nn/argane/internal/policies"
	"github.com/kkrypt0nn/argane/internal/reporters"
	"github.com/kkrypt0nn/argane/internal/rule"
	"github.com/kkrypt0nn/argane/internal/util"
	"github.com/spf13/cobra"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
	"k8s.io/client-go/util/homedir"
)

// https://github.com/kubernetes/client-go/blob/master/examples/out-of-cluster-client-configuration/main.go

var (
	namespace   string
	contextName string
	kubeconfig  string
)

func init() {
	evalCmd.AddCommand(evalk8sCmd)

	evalk8sCmd.PersistentFlags().StringVarP(
		&namespace,
		"namespace",
		"n",
		"default",
		"Namespace of the resource",
	)

	evalk8sCmd.PersistentFlags().StringVarP(
		&contextName,
		"context",
		"c",
		"",
		"The context of the kubeconfig file to use, default is the currently active one",
	)

	var kubeconfigPath string
	if home := homedir.HomeDir(); home != "" {
		kubeconfigPath = filepath.Join(home, ".kube", "config")
	}
	evalk8sCmd.PersistentFlags().StringVarP(
		&kubeconfig,
		"kubeconfig",
		"k",
		kubeconfigPath,
		"Absolute path to the kubeconfig file",
	)
	flag := evalk8sCmd.PersistentFlags().Lookup("kubeconfig")
	flag.DefValue = "$HOME/.kube/config"
}

var evalk8sCmd = &cobra.Command{
	Use:   "k8s <resource>/<name>",
	Short: "Evaluate a pod-compatible running workload from the current kubeconfig against the Kubernetes Pod Security Standards.",
	Args:  cobra.ExactArgs(1),
	Run: func(cmd *cobra.Command, args []string) {
		parts := strings.SplitN(args[0], "/", 2)
		if len(parts) != 2 {
			util.LogError("Invalid input, expected format <resource>/<name>")
			os.Exit(1)
		}
		resource, name := parts[0], parts[1]

		overrides := &clientcmd.ConfigOverrides{}
		if contextName != "" {
			overrides.CurrentContext = contextName
		}
		configLoadingRules := &clientcmd.ClientConfigLoadingRules{
			ExplicitPath: kubeconfig,
		}
		clientConfig := clientcmd.NewNonInteractiveDeferredLoadingClientConfig(
			configLoadingRules,
			overrides,
		)

		config, err := clientConfig.ClientConfig()
		if err != nil {
			util.LogError(fmt.Sprintf("Failed to use the kubeconfig context: %v", err))
			os.Exit(1)
		}
		clientset, err := kubernetes.NewForConfig(config)
		if err != nil {
			util.LogError(fmt.Sprintf("Failed to create the clientset: %v", err))
			os.Exit(1)
		}

		var spec *corev1.PodSpec
		switch resource {
		case "cronjob":
			cronjob, err := clientset.BatchV1().CronJobs(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get CronJob %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &cronjob.Spec.JobTemplate.Spec.Template.Spec
		case "daemonset":
			daemonset, err := clientset.AppsV1().DaemonSets(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get DaemonSet %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &daemonset.Spec.Template.Spec
		case "deployment":
			deployment, err := clientset.AppsV1().Deployments(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get Deployment %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &deployment.Spec.Template.Spec
		case "job":
			job, err := clientset.BatchV1().Jobs(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get Job %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &job.Spec.Template.Spec
		case "pod":
			pod, err := clientset.CoreV1().Pods(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get Pod %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &pod.Spec
		case "statefulset":
			statefulset, err := clientset.AppsV1().StatefulSets(namespace).Get(cmd.Context(), name, metav1.GetOptions{})
			if err != nil {
				util.LogError(fmt.Sprintf("Failed to get StatefulSet %s/%s: %v", namespace, name, err))
				os.Exit(1)
			}
			spec = &statefulset.Spec.Template.Spec
		default:
			util.LogError("Invalid resource type. Must be 'cronjob', 'daemonset', 'deployment', 'job', 'pod' or 'statefulset'")
			os.Exit(1)
		}

		var selectedPolicy []rule.Rule
		switch policy {
		case "baseline":
			selectedPolicy = policies.BaselinePolicy(disabledRules)
		case "restricted":
			selectedPolicy = policies.RestrictedPolicy(disabledRules)
		default:
			util.LogError("Invalid policy. Must be 'baseline' or 'restricted'")
			os.Exit(1)
		}

		e := engine.New(selectedPolicy)
		reporter := reporters.NewReporter(output, selectedPolicy, violationsOnly)

		result := e.Evaluate(spec, fmt.Sprintf("%s/%s", resource, name))

		reporter.Print([]*engine.Result{result})
		if !result.IsClean() {
			os.Exit(1)
		}
		os.Exit(0)
	},
}
