---
title: Quickstart Guide
description: Quickstart Guide
sidebar:
  order: 1
---

### Example Usage

```bash
argane eval file ./testdata/baseline/invalid/host_process.yaml -p baseline

cat ./testdata/restricted/invalid/capabilities.yaml | argane eval stdin

docker run -v ./testdata:/testdata kkrypt0nn/argane eval file /testdata/baseline/valid/hostpath_volumes.yaml -p baseline
```
