---
title: Overview
description: Argane is a Kubernetes security validator for YAML manifests, Helm charts, and running pods.
sidebar:
  order: 1
---

### 🕵️ Your Kubernetes pod security detective

**Argane** is a Kubernetes security validator for YAML manifests, Helm charts, and running pods. It checks your workloads against the [Kubernetes Pod Security Standards](https://kubernetes.io/docs/concepts/security/pod-security-standards/) and reports any violations, helping you identify security issues such as host namespaces, privileged containers, capabilities and other security settings.

Argane is designed to be a lightweight, developer-friendly tool that helps you catch pod security misconfigurations **early**, before they even reach your cluster.

## Features

- Validate workloads against Kubernetes Pod Security Standards (`privileged` or `baseline`)
- Multiple input sources are supported
  - YAML manifests
  - Rendered Helm charts
  - stdin
  - Running pods on a cluster
- Clear violation reporting with multiple output formatting including JSON
- Fast and CLI-friendly, built for CI pipelines

## Goals

- Help developers and operators identify insecure pod configurations **before** deployment
- Enable security validation during code review and CI rather than only at runtime
- Stay as close as possible to the Kubernetes Pod Security Standards for more predictable and consistent results

## Non-goals

- Argane **does not** block workloads or enforce policies in-cluster, there are already amazing tools for that, including the built-in [admission enforcement](https://kubernetes.io/docs/concepts/security/pod-security-admission/) of Kubernetes
- Argane **is not** a vulnerability scanner and does not scan images for any kind of CVEs
