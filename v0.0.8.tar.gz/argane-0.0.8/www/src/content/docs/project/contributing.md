---
title: Contributing
description: Contributions are more than welcome.
sidebar:
  order: 3
---

Contributions are more than welcome, but please wait until we release a working beta or alpha version, then the issues will also be opened.

When it's time, please follow:
- [Contributing Guidelines](https://github.com/kkrypt0nn/argane/blob/main/CONTRIBUTING.md)
- [Code of Conduct](https://github.com/kkrypt0nn/argane/blob/main/CODE_OF_CONDUCT.md)
