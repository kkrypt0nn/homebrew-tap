package decoder

import (
	"bytes"
	"io"

	appsv1 "k8s.io/api/apps/v1"
	batchv1 "k8s.io/api/batch/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/serializer"
	k8syaml "k8s.io/apimachinery/pkg/util/yaml"
)

var scheme = runtime.NewScheme()

func init() {
	_ = corev1.AddToScheme(scheme)
	_ = appsv1.AddToScheme(scheme)
}

func DecodePodSpecs(yamlBytes []byte) ([]*corev1.PodSpec, error) {
	deserializer := serializer.NewCodecFactory(scheme).UniversalDeserializer()
	decoder := k8syaml.NewYAMLOrJSONDecoder(bytes.NewReader(yamlBytes), 4096)

	var specs []*corev1.PodSpec
	for {
		var raw runtime.RawExtension
		if err := decoder.Decode(&raw); err != nil {
			if err == io.EOF {
				break
			}
			return nil, err
		}

		if len(raw.Raw) == 0 {
			continue
		}

		spec, err := decodePodSpec(raw.Raw, deserializer)
		if err != nil {
			return nil, err
		}
		if spec != nil {
			specs = append(specs, spec)
		}
	}

	return specs, nil
}

func decodePodSpec(raw []byte, deserializer runtime.Decoder) (*corev1.PodSpec, error) {
	obj, _, err := deserializer.Decode(raw, nil, nil)
	if err != nil {
		if runtime.IsNotRegisteredError(err) || meta.IsNoMatchError(err) {
			return nil, nil
		}
		return nil, err
	}

	if pod, ok := obj.(*corev1.Pod); ok {
		return &pod.Spec, nil
	}

	if spec := podSpecFromWorkload(obj); spec != nil {
		return spec, nil
	}

	return nil, nil
}

func podSpecFromWorkload(obj runtime.Object) *corev1.PodSpec {
	switch o := obj.(type) {
	case *appsv1.DaemonSet:
		return &o.Spec.Template.Spec
	case *appsv1.Deployment:
		return &o.Spec.Template.Spec
	case *appsv1.StatefulSet:
		return &o.Spec.Template.Spec
	case *batchv1.Job:
		return &o.Spec.Template.Spec
	case *batchv1.CronJob:
		return &o.Spec.JobTemplate.Spec.Template.Spec
	}
	return nil
}
