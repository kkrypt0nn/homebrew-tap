package rule

type Violation struct {
	RuleID  string
	Message string
	Field   string
}
