package util

const (
	Reset = "\033[0m"

	FgBlack = "\033[30m"
	FgWhite = "\033[97m"
	FgGray  = "\033[90m"

	BgGreen     = "\033[42m"
	BgRed       = "\033[41m"
	BgBrightRed = "\033[101m"
	BgBlue      = "\033[44m"
)
