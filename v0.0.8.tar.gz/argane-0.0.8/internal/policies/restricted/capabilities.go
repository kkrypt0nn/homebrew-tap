package restricted

import (
	"slices"

	"github.com/kkrypt0nn/argane/internal/rule"
	"github.com/kkrypt0nn/argane/internal/util"
	corev1 "k8s.io/api/core/v1"
)

type CapabilitiesRule struct{}

func (r CapabilitiesRule) ID() string {
	return "pss:restricted:capabilities"
}

func (r CapabilitiesRule) MarkdownDescription() string {
	return "_To be written_"
}

func (r CapabilitiesRule) Evaluate(podSpec *corev1.PodSpec) []rule.Violation {
	if util.IsWindows(podSpec.OS) {
		return nil
	}

	var violations []rule.Violation

	r.checkContainers(&violations, podSpec.Containers, "spec.containers")
	r.checkContainers(&violations, podSpec.InitContainers, "spec.initContainers")
	r.checkEphemeralContainers(&violations, podSpec.EphemeralContainers, "spec.ephemeralContainers")

	return violations
}

func (r CapabilitiesRule) check(caps *corev1.Capabilities, base string) []rule.Violation {
	var violations []rule.Violation

	if caps == nil {
		violations = append(violations, rule.Violation{
			RuleID:  r.ID(),
			Message: "All capabilities must be dropped",
			Field:   base + ".drop",
		})
		return violations
	}

	if !slices.Contains(caps.Drop, "ALL") {
		violations = append(violations, rule.Violation{
			RuleID:  r.ID(),
			Message: "All capabilities must be dropped",
			Field:   base + ".drop",
		})
	}

	for _, cap := range caps.Add {
		if cap != "NET_BIND_SERVICE" {
			violations = append(violations, rule.Violation{
				RuleID:  r.ID(),
				Message: "Only NET_BIND_SERVICE capability may be added",
				Field:   base + ".add",
			})
		}
	}

	return violations
}

func (r CapabilitiesRule) checkContainers(
	violations *[]rule.Violation,
	containers []corev1.Container,
	base string,
) {
	for i, c := range containers {
		if c.SecurityContext == nil {
			continue
		}

		util.AppendViolations(
			violations,
			r.check(
				c.SecurityContext.Capabilities,
				util.FieldPath(base, i, "securityContext.capabilities"),
			),
		)
	}
}

func (r CapabilitiesRule) checkEphemeralContainers(
	violations *[]rule.Violation,
	containers []corev1.EphemeralContainer,
	base string,
) {
	for i, c := range containers {
		if c.SecurityContext == nil {
			continue
		}

		util.AppendViolations(
			violations,
			r.check(
				c.SecurityContext.Capabilities,
				util.FieldPath(base, i, "securityContext.capabilities"),
			),
		)
	}
}
