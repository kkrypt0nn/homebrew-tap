package restricted

import (
	"github.com/kkrypt0nn/argane/internal/rule"
	"github.com/kkrypt0nn/argane/internal/util"
	corev1 "k8s.io/api/core/v1"
)

type PrivilegeEscalationRule struct{}

func (r PrivilegeEscalationRule) ID() string {
	return "pss:restricted:privilege_escalation"
}

func (r PrivilegeEscalationRule) MarkdownDescription() string {
	return "_To be written_"
}

func (r PrivilegeEscalationRule) Evaluate(podSpec *corev1.PodSpec) []rule.Violation {
	if util.IsWindows(podSpec.OS) {
		return nil
	}

	var violations []rule.Violation

	r.checkContainers(&violations, podSpec.Containers, "spec.containers")
	r.checkContainers(&violations, podSpec.InitContainers, "spec.initContainers")
	r.checkEphemeralContainers(&violations, podSpec.EphemeralContainers, "spec.ephemeralContainers")

	return violations
}

func (r PrivilegeEscalationRule) check(field string, allowPrivilegeEscalation *bool) *rule.Violation {
	if allowPrivilegeEscalation != nil && !*allowPrivilegeEscalation {
		return nil
	}

	return &rule.Violation{
		RuleID:  r.ID(),
		Message: "allowPrivilegeEscalation must be false",
		Field:   field,
	}
}

func (r PrivilegeEscalationRule) checkContainers(
	violations *[]rule.Violation,
	containers []corev1.Container,
	base string,
) {
	for i, c := range containers {
		if c.SecurityContext == nil {
			continue
		}

		util.AppendIfViolation(
			violations,
			r.check(
				util.FieldPath(base, i, "securityContext.allowPrivilegeEscalation"),
				c.SecurityContext.AllowPrivilegeEscalation,
			),
		)
	}
}

func (r PrivilegeEscalationRule) checkEphemeralContainers(
	violations *[]rule.Violation,
	containers []corev1.EphemeralContainer,
	base string,
) {
	for i, c := range containers {
		if c.SecurityContext == nil {
			continue
		}

		util.AppendIfViolation(
			violations,
			r.check(
				util.FieldPath(base, i, "securityContext.allowPrivilegeEscalation"),
				c.SecurityContext.AllowPrivilegeEscalation,
			),
		)
	}
}
