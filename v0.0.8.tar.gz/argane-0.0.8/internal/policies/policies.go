package policies

import (
	"github.com/kkrypt0nn/argane/internal/policies/baseline"
	"github.com/kkrypt0nn/argane/internal/policies/restricted"
	"github.com/kkrypt0nn/argane/internal/rule"
)

func BaselinePolicy(disabledIDs []string) []rule.Rule {
	baselineRules := []rule.Rule{
		baseline.AppArmorRule{},
		baseline.CapabilitiesRule{},
		baseline.HostNamespacesRule{},
		baseline.HostPortsRule{},
		baseline.HostProbesRule{},
		baseline.HostProcessRule{},
		baseline.HostpathVolumesRule{},
		baseline.PrivilegedContainersRule{},
		baseline.ProcMountTypeRule{},
		baseline.SeccompRule{},
		baseline.SELinuxRule{},
		baseline.SysctlsRule{},
	}
	return filterRules(baselineRules, disabledIDs)
}

func RestrictedPolicy(disabledIDs []string) []rule.Rule {
	restrictedRules := append(
		BaselinePolicy(disabledIDs),
		restricted.CapabilitiesRule{},
		restricted.PrivilegeEscalationRule{},
		restricted.RunningAsNonRootRule{},
		restricted.RunningAsNonRootUserRule{},
		restricted.SeccompRule{},
		restricted.VolumeTypesRule{},
	)
	return filterRules(restrictedRules, disabledIDs)
}

func filterRules(rules []rule.Rule, disabledIDs []string) []rule.Rule {
	if len(disabledIDs) == 0 {
		return rules
	}

	disabled := make(map[string]struct{}, len(disabledIDs))
	for _, id := range disabledIDs {
		disabled[id] = struct{}{}
	}

	filtered := make([]rule.Rule, 0, len(rules))
	for _, r := range rules {
		if _, found := disabled[r.ID()]; !found {
			filtered = append(filtered, r)
		}
	}

	return filtered
}
