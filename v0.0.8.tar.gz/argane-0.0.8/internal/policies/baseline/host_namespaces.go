package baseline

import (
	"github.com/kkrypt0nn/argane/internal/rule"
	"github.com/kkrypt0nn/argane/internal/util"
	corev1 "k8s.io/api/core/v1"
)

type HostNamespacesRule struct{}

func (r HostNamespacesRule) ID() string {
	return "pss:baseline:host_namespaces"
}

func (r HostNamespacesRule) MarkdownDescription() string {
	return "_To be written_"
}

func (r HostNamespacesRule) Evaluate(podSpec *corev1.PodSpec) []rule.Violation {
	var violations []rule.Violation

	util.AppendIfViolation(
		&violations,
		r.check(
			podSpec.HostNetwork,
			"spec.hostNetwork",
			"hostNetwork must be unset or false",
		),
	)

	util.AppendIfViolation(
		&violations,
		r.check(
			podSpec.HostPID,
			"spec.hostPID",
			"hostPID must be unset or false",
		),
	)

	util.AppendIfViolation(
		&violations,
		r.check(
			podSpec.HostIPC,
			"spec.hostIPC",
			"hostIPC must be unset or false",
		),
	)

	return violations
}

func (r HostNamespacesRule) check(enabled bool, field string, message string) *rule.Violation {
	if !enabled {
		return nil
	}

	return &rule.Violation{
		RuleID:  r.ID(),
		Message: message,
		Field:   field,
	}
}
