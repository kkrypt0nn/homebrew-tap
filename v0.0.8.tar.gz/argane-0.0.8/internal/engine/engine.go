package engine

import (
	"github.com/kkrypt0nn/argane/internal/rule"
	corev1 "k8s.io/api/core/v1"
)

type Engine struct {
	Rules []rule.Rule
}

func New(rules []rule.Rule) *Engine {
	return &Engine{
		Rules: rules,
	}
}

func (e *Engine) Evaluate(spec *corev1.PodSpec, resourceName string) *Result {
	var violations []rule.Violation

	for _, r := range e.Rules {
		violations = append(violations, r.Evaluate(spec)...)
	}

	return &Result{
		ResourceName: resourceName,
		Violations:   violations,
	}
}
