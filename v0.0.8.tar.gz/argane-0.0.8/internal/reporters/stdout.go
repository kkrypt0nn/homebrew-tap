package reporters

import (
	"github.com/kkrypt0nn/argane/internal/engine"
	"github.com/kkrypt0nn/argane/internal/rule"
	"github.com/kkrypt0nn/argane/internal/util"
)

type StdoutReporter struct {
	Policy         []rule.Rule
	ViolationsOnly bool
}

func (rep *StdoutReporter) Print(results []*engine.Result) {
	for _, result := range results {
		for _, rRule := range rep.Policy {
			if vs, failed := result.ByRule()[rRule.ID()]; failed {
				for _, v := range vs {
					util.PrintResult(
						util.StatusFail,
						rRule.ID(),
						result.ResourceName,
						v.Message+" ("+v.Field+")",
					)
				}
			} else if !rep.ViolationsOnly {
				util.PrintResult(
					util.StatusPass,
					rRule.ID(),
					result.ResourceName,
					"",
				)
			}
		}
	}
}
